package com.ism.entities;

public class Personne {
    private int id;
    private String nomComplet;

    public Personne(int id, String nomComplet) {
        this.id = id;
        this.nomComplet = nomComplet;
    }

    public int getId() {
        return id;
    }

    public String getNomComplet() {
        return nomComplet;
    }

    @Override
    public String toString() {
        return "Personne{id=" + id + ", nomComplet='" + nomComplet + '\'' + '}';
    }
}
