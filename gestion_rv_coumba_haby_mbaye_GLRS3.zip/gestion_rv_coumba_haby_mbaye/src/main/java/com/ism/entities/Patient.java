package com.ism.entities;

public class Patient extends Personne {

    private String antecedants;

    public Patient(int id, String nomComplet, String antecedants) {
        super(id, nomComplet);
        this.antecedants = antecedants;
    }

    public String getAntecedants() {
        return antecedants;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "id=" + getId() +
                ", nomComplet='" + getNomComplet() + '\'' +
                ", antecedants='" + antecedants + '\'' +
                '}';
    }
}
