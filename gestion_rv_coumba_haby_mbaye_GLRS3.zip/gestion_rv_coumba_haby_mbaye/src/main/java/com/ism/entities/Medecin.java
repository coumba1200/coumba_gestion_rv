package com.ism.entities;

public class Medecin extends Personne {

    private String specialite;

    public Medecin(int id, String nomComplet, String specialite) {
        super(id, nomComplet);
        this.specialite = specialite;
    }

    public String getSpecialite() {
        return specialite;
    }

    @Override
    public String toString() {
        return "Medecin{" +
                "id=" + getId() +
                ", nomComplet='" + getNomComplet() + '\'' +
                ", specialite='" + specialite + '\'' +
                '}';
    }
}
