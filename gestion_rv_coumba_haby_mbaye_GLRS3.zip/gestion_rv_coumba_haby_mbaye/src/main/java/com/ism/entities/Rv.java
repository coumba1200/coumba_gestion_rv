package com.ism.entities;

import java.sql.Date;
import java.sql.Time;

public class Rv {
    private int id;
    private Date date;
    private Time heure;
    private Medecin medecin;
    private Patient patient;

    public Rv(int id, Date date, Time heure, Medecin medecin, Patient patient) {
        this.id = id;
        this.date = date;
        this.heure = heure;
        this.medecin = medecin;
        this.patient = patient;
    }

    public int getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    public Time getHeure() {
        return heure;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public Patient getPatient() {
        return patient;
    }

    @Override
    public String toString() {
        return "Rv{" +
                "id=" + id +
                ", date=" + date +
                ", heure=" + heure +
                ", medecin=" + medecin +
                ", patient=" + patient +
                '}';
    }
}
