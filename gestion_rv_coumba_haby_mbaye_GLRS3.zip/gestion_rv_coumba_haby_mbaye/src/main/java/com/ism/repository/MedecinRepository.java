package com.ism.repository;

import com.ism.entities.Medecin;

public interface MedecinRepository extends Repository<Medecin> {
}

