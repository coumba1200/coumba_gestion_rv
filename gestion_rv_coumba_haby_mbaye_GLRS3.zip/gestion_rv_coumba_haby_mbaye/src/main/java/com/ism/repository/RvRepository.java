package com.ism.repository;

import com.ism.entities.Rv;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RvRepository implements Repository<Rv> {

    private final Connection connection;

    public RvRepository(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void creer(Rv entity) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO RV (date, heure, idPatient, idMedecin) VALUES (?, ?, ?, ?)")) {
            preparedStatement.setDate(1, entity.getDate());
            preparedStatement.setTime(2, entity.getHeure());
            preparedStatement.setInt(3, entity.getPatient().getId());
            preparedStatement.setInt(4, entity.getMedecin().getId());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Rv> getRvDuJour(Date date) {
        List<Rv> rvList = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM RV WHERE date = ?")) {
            preparedStatement.setDate(1, date);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                Time heure = resultSet.getTime("heure");
                int idPatient = resultSet.getInt("idPatient");
                int idMedecin = resultSet.getInt("idMedecin");

                // Vous devez obtenir les instances de Patient et Medecin ici en fonction des IDs
                // Ces lignes sont des exemples
                Patient patient = new PatientRepository(connection).getById(idPatient);
                Medecin medecin = new MedecinRepository(connection).getById(idMedecin);

                Rv rv = new Rv(id, date, heure, medecin, patient);
                rvList.add(rv);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rvList;
    }

    public List<Rv> getRvMedecinParJour(int idMedecin, Date date) {
        List<Rv> rvList = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM RV WHERE idMedecin = ? AND date = ?")) {
            preparedStatement.setInt(1, idMedecin);
            preparedStatement.setDate(2, date);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                Time heure = resultSet.getTime("heure");
                int idPatient = resultSet.getInt("idPatient");

                // Vous devez obtenir l'instance de Patient ici en fonction de l'ID
                // Cette ligne est un exemple
                Patient patient = new PatientRepository(connection).getById(idPatient);

                Rv rv = new Rv(id, date, heure, new Medecin(idMedecin, "", ""), patient);
                rvList.add(rv);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rvList;
    }

    public void annulerRv(int idRv) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM RV WHERE id = ?")) {
            preparedStatement.setInt(1, idRv);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

