public class TablePatient {
    
}
