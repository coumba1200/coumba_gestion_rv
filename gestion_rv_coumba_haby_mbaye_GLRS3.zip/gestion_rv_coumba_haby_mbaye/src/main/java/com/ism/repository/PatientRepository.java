package com.ism.repository;

import com.ism.entities.Patient;

public interface PatientRepository extends Repository<Patient> {
}
