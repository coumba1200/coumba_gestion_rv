package com.ism.repository;

public interface Repository<T> {
    void creer(T entity);
   
}
