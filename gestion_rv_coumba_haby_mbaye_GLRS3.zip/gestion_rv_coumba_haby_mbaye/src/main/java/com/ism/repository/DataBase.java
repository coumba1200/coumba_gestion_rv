package com.ism.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

public class DataBase {

    private static final String URL = "jdbc:mysql://localhost:3306/nom_base_de_donnees";
    private static final String UTILISATEUR = "utilisateur";
    private static final String MOT_DE_PASSE = "mot_de_passe";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, UTILISATEUR, MOT_DE_PASSE);
    }

    public static void creerPatient(String nomComplet, String antecedants) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Patient (nomComplet, antecedants) VALUES (?, ?)")) {

            preparedStatement.setString(1, nomComplet);
            preparedStatement.setString(2, antecedants);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void creerMedecin(String nomComplet, String specialite) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Medecin (nomComplet, specialite) VALUES (?, ?)")) {

            preparedStatement.setString(1, nomComplet);
            preparedStatement.setString(2, specialite);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void creerRV(int idPatient, int idMedecin, Date date, Time heure) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO RV (idPatient, idMedecin, date, heure) VALUES (?, ?, ?, ?)")) {

            preparedStatement.setInt(1, idPatient);
            preparedStatement.setInt(2, idMedecin);
            preparedStatement.setDate(3, date);
            preparedStatement.setTime(4, heure);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
