package com.ism;

import com.ism.entities.Medecin;
import com.ism.entities.Patient;
import com.ism.entities.Rv;
import com.ism.repository.DataBase;
import com.ism.repository.MedecinRepository;
import com.ism.repository.PatientRepository;
import com.ism.repository.RvRepository;
import com.ism.repository.Repository;
import com.ism.service.MedecinService;
import com.ism.service.PatientService;
import com.ism.service.RendezVousService;
import com.ism.service.RendezVousServiceImpl;

import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Repository<Patient> patientRepository = new PatientRepository(DataBase.getConnection());
        Repository<Medecin> medecinRepository = new MedecinRepository(DataBase.getConnection());
        RvRepository rvRepository = new RvRepository(DataBase.getConnection());

        PatientService patientService = new PatientService(patientRepository);
        MedecinService medecinService = new MedecinService(medecinRepository);
        RendezVousService rendezVousService = new RendezVousServiceImpl(rvRepository);

        Scanner scanner = new Scanner(System.in);

        int choix;
        do {
            System.out.println("1-Créer un patient");
            System.out.println("2-Créer un médecin");
            System.out.println("3-Planifier un rendez-vous");
            System.out.println("4-Afficher les rendez-vous du jour");
            System.out.println("5-Afficher les rendez-vous d'un médecin par jour");
            System.out.println("6-Annuler un rendez-vous");
            System.out.println("7-Quitter");

            choix = scanner.nextInt();

            switch (choix) {
                case 1:
                    creerPatient(patientService);
                    break;
                case 2:
                    creerMedecin(medecinService);
                    break;
                case 3:
                    planifierRv(rendezVousService, patientService, medecinService);
                    break;
                case 4:
                    afficherRvDuJour(rendezVousService);
                    break;
                case 5:
                    afficherRvMedecinParJour(rendezVousService, medecinService);
                    break;
                case 6:
                    annulerRv(rendezVousService);
                    break;
                case 7:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        } while (choix != 7);
    }

    private static void creerPatient(PatientService patientService) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez le nom complet du patient : ");
        String nomComplet = scanner.nextLine();
        System.out.println("Entrez les antécédents du patient : ");
        String antecedants = scanner.nextLine();

        Patient patient = new Patient(0, nomComplet, antecedants);
        patientService.creer(patient);

        System.out.println("Patient créé avec succès !");
    }

    private static void creerMedecin(MedecinService medecinService) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez le nom complet du médecin : ");
        String nomComplet = scanner.nextLine();
        System.out.println("Entrez la spécialité du médecin : ");
        String specialite = scanner.nextLine();

        Medecin medecin = new Medecin(0, nomComplet, specialite);
        medecinService.creer(medecin);

        System.out.println("Médecin créé avec succès !");
    }

    private static void planifierRv(RendezVousService rendezVousService, PatientService patientService, MedecinService medecinService) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez l'ID du patient : ");
        int idPatient = scanner.nextInt();
        System.out.println("Entrez l'ID du médecin : ");
        int idMedecin = scanner.nextInt();
        System.out.println("Entrez la date du rendez-vous (AAAA-MM-JJ) : ");
        Date date = Date.valueOf(scanner.next());
        System.out.println("Entrez l'heure du rendez-vous (HH:MM:SS) : ");
        Time heure = Time.valueOf(scanner.next());

        Patient patient = patientService.getById(idPatient);
        Medecin medecin = medecinService.getById(idMedecin);

        Rv rv = new Rv(0, date, heure, medecin, patient);
        rendezVousService.creer(rv);

        System.out.println("Rendez-vous planifié avec succès !");
    }

    private static void afficherRvDuJour(RendezVousService rendezVousService) {
        // Implémentez la logique pour afficher les rendez-vous du jour
    }

    private static void afficherRvMedecinParJour(RendezVousService rendezVousService, MedecinService medecinService) {
        // Implémentez la logique pour afficher les rendez-vous d'un médecin par jour
    }

    private static void annulerRv(RendezVousService rendezVousService) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez l'ID du rendez-vous à annuler : ");
        int idRv = scanner.nextInt();
        rendezVousService.annulerRv(idRv);
        System.out.println("Rendez-vous annulé avec succès !");
    }
}
