package com.ism.service;

import com.ism.entities.Medecin;
import com.ism.repository.MedecinRepository;

public class MedecinService implements PersonneService {

    private final MedecinRepository medecinRepository;

    public MedecinService(MedecinRepository medecinRepository) {
        this.medecinRepository = medecinRepository;
    }

    @Override
    public void creer(Medecin entity) {
        medecinRepository.creer(entity);
    }
}

