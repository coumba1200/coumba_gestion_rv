package com.ism.service;

public interface Service<T> {
    void creer(T entity);
}

//TTES LES METHODES EN COMMUN