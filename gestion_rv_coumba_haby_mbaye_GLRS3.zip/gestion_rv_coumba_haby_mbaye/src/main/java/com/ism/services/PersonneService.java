package com.ism.service;

import com.ism.entities.Personne;

public interface PersonneService extends Service<Personne> {
}

