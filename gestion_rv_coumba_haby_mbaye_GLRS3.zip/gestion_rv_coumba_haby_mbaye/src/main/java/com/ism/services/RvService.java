package com.ism.service;

import com.ism.entities.Rv;

public interface RvService extends Service<Rv> {
    // Ajoutez d'autres méthodes spécifiques aux rendez-vous si nécessaire
}


//definir ici ttes les fonctionnalités 
//annuler un rv(),
// plannifier un rv () ,
//afficher les rv()
