package com.ism.service;

import com.ism.entities.Rv;
import com.ism.repository.RvRepository;

import java.sql.Date;
import java.sql.Time;

public class RvServiceImpl implements RvService {

    private final RvRepository rvRepository;

    public RvServiceImpl(RvRepository rvRepository) {
        this.rvRepository = rvRepository;
    }

    @Override
    public void creer(Rv entity) {
        rvRepository.creer(entity);
    }

}
