package com.ism.service;

import com.ism.entities.Rv;
import com.ism.repository.RvRepository;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

public class RendezVousServiceImpl implements RendezVousService {

    private final RvRepository rvRepository;

    public RendezVousServiceImpl(RvRepository rvRepository) {
        this.rvRepository = rvRepository;
    }

    @Override
    public void creer(Rv entity) {
        rvRepository.creer(entity);
    }

    @Override
    public List<Rv> afficherRvDuJour() {
        // Implémentez la logique pour afficher les RV du jour
        return null;
    }

    @Override
    public List<Rv> afficherRvMedecinParJour(int idMedecin) {
        // Implémentez la logique pour afficher les RV d'un médecin par jour
        return null;
    }

    @Override
    public void annulerRv(int idRv) {
        // Implémentez la logique pour annuler un RV
    }
}

