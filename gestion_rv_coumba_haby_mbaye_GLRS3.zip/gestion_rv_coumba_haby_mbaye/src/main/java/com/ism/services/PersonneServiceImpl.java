package com.ism.service;

import com.ism.entities.Personne;
import com.ism.repository.Repository;

public class PersonneServiceImpl implements PersonneService {

    private final Repository<Personne> repository;

    public PersonneServiceImpl(Repository<Personne> repository) {
        this.repository = repository;
    }

    @Override
    public void creer(Personne entity) {
        repository.creer(entity);
    }
}

