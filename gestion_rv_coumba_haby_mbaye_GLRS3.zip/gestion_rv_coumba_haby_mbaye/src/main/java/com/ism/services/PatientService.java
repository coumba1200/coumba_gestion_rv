package com.ism.service;

import com.ism.entities.Patient;
import com.ism.repository.PatientRepository;

public class PatientService implements PersonneService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    @Override
    public void creer(Patient entity) {
        patientRepository.creer(entity);
    }
}

