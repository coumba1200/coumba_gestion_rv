package com.ism.service;

import com.ism.entities.Rv;

import java.util.List;

public interface RendezVousService extends RvService {
    List<Rv> afficherRvDuJour();
    List<Rv> afficherRvMedecinParJour(int idMedecin);
    void annulerRv(int idRv);
}

